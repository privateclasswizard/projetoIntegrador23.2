import Reacts from "react";

const ConfirmarHorario = () => {
    return (
        <div>
            <h1>Confirmar Horario Page</h1>
        </div>
    )
}

export default ConfirmarHorario