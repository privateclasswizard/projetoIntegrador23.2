import Reacts from "react";

const RegistroBarbeiro = () => {
    return (
        <div>
            <h1>RegistroBarbeiro Page</h1>
        </div>
    )
}

export default RegistroBarbeiro