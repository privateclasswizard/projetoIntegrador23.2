import './App.css'

function App() {
  return (
    <div>
      <h1>React Router</h1>
    </div>
  )
}

export default App
